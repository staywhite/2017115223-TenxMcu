#include <REGtenxTM52F5278B.h>

#include "typeAlias.h"

#include "display.h"
#include "init.h"
#include "isr.h"
#include "keys.h"
#include "main.h"
#include <INTRINS.H>
