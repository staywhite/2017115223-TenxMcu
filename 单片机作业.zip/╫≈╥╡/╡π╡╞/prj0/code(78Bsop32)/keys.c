#define __keys_c
#include "includeAll.h"
//=============================================================================
void GetKeys() {
  if (P_key1 == 0) {
    keyValue = D_keyValue1;
  }
}